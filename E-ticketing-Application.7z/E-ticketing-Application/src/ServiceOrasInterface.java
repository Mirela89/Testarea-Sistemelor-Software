import java.util.List;

public interface ServiceOrasInterface {
    public void sorteazaEvenimenteleDupaOras(List<Eveniment> evenimente);

    public void sorteazaEvenimenteleDupaOrasSiData(List<Eveniment> evenimente);


}
