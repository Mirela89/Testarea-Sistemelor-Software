import java.util.List;

public interface ServiceTipInterface {
    public void sorteazaEvenimenteleDupaTip(List<Eveniment> evenimente);

    public void sorteazaEvenimenteleDupaTipsiData(List<Eveniment> evenimente);
}
