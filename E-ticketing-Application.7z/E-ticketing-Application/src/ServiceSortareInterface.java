import java.util.List;

public interface ServiceSortareInterface {
    public void sorteazaEvenimenteleDupaDenumire(List<Eveniment> evenimente);

    public void sorteazaEvenimenteleDupaNumarulDeBileteRamase(List<Eveniment> evenimente);
}
